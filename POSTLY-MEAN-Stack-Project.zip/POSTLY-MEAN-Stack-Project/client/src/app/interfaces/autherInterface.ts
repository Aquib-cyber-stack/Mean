export interface IAuthor {
	username: string;
	imgUrl: string;
}