// node_modules/@angular/cdk/fesm2022/coercion.mjs
function coerceBooleanProperty(value) {
  return value != null && `${value}` !== "false";
}

export {
  coerceBooleanProperty
};
//# sourceMappingURL=chunk-AZ3XZ4SL.js.map
